import pylab as plt
import numpy as np
    
def plot(points):
    plt.figure(figsize=(16,9))
    rangee = {'top': 10, 'bot': 0}
    
    plt.ylim(rangee['bot'], rangee['top'])

    for line in points:
        plt.plot(line)

    plt.legend()
    plt.show()

def read_csv(path):
    # chan1, chan2, chan3, chan4 = [],[],[],[]
    chan1 = []
    with open(path) as file:
        # i = 0
        for data_row in file.readlines():
            c1 = data_row.split(',')
            for x in c1[1:]:
                try:
                    chan1.append(float(x))
                except ValueError:
                    print(x)
    return chan1

def normilaze(chan):
    LOW_LEVEL = 3
    OVERAGE_BOTTOM = 0
    temp = 0
    for x in range(len(chan1)):
        if (chan[x] < LOW_LEVEL and chan[x] > 0):
            print('OVERAGE: ' + str(OVERAGE_BOTTOM))
            OVERAGE_BOTTOM *= temp
            temp += 1
            OVERAGE_BOTTOM += chan[x]
            OVERAGE_BOTTOM /= temp
            chan[x] = OVERAGE_BOTTOM
        elif(chan[x] < 0 and chan[x] < LOW_LEVEL):
            chan[x] = chan[x - 1]
    return chan

def resist(chan1, chan2):
    RESISTENCE = 38.4
    LOW_LEVEL = 3
    chan3 = []
    temp = 0
    for i in range(min(len(chan2), len(chan1))):
        if (chan1[i] < LOW_LEVEL and chan1[i] > 0):
            temp = RESISTENCE / (chan1[i] / chan2[i])
            print('-----------------------')
            print('POWER: ' + str(chan1[i] / chan2[i]))
            print('RESISTENCE: ' + str(temp))
            print('-----------------------')
        if (temp > 6):
            try:
                temp = chan3[i - 1]
                chan3.append(temp)            
            except IndexError:
                print("ERROR")
        else:
            chan3.append(temp)
    return chan3

if __name__ == "__main__":
    to_draft = []

    DATA_EXTENSION = '.txt'
    phases = ['0%', '10%', '20%', '30%', '40%', '50%', '60%', '70%', '80%', '90%', '100%']

    path = ['./chan1_', './chan2_']

    for phase in phases: 
        chan1 = read_csv(path[0] + phase + DATA_EXTENSION)
        chan2 = read_csv(path[1] + phase + DATA_EXTENSION)
        chan1 = normilaze(chan1)

        for x in range(len(chan2)):
            if chan2[x] < 0.2:
                chan2[x] = 0.15
        to_draft.append(resist(chan1, chan2))


    plot(to_draft)
