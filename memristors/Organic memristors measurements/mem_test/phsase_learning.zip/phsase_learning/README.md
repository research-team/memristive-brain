# INFO ABOUT DATA



## First of all:
* Input size - 5ms
* Input period - 50ms

## About meassurement:
* 100 points = 20ms
* 10% phase = 1.5ms